<?php
/**
 * using mysqli_connect for database connection
 */

$databaseHost = 'localhost';
$databaseName = 'id12936388_crud_db';
$databaseUsername = 'id12936388_pandi_db';
$databasePassword = 'arianza12';

$mysqli = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName); 

?>